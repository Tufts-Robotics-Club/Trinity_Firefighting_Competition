#!/usr/bin/env bash

python waitSound.py

python3 blinkBlue.py &
python3 traverseMaze.py

