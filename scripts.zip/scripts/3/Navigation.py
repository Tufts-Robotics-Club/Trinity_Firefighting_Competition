# Andrew Wang
# Trinity Competition Spring 2018
# @TODO: Doesn't work

import time
import math

import wheels
import fireSensor
import distanceSensors
import extinguishFire

SIDE_THRESHOLD = 5
FIRST_THRESHOLD = 3
TURN_TIME = 1
NO_FIRE = 1000


#FUNCTIONS PASSED TO THIS CODE
# def ultrasonicInfo = distanceSensors.getDistances():
# 	print("getting ultrasoncis")
# #passive fire v
# def passiveFireSensor():
# 	print("passiveFireSensor firing")
# 	return 0
# def activeFireSensor():
# 	print("activeFireSensor firing")
# 	return 0
# def wheels.rotateAngle(degrees):
# 	print("rotatingInPlace " + str(degrees) + " degrees")
# def drive(x, y):
# 	print("driving to position vector (" + str(x) + ", " + str(y) + ").")
# 	print("Magnitude is " + str(math.sqrt(x**2 + y**2)))
# 	if not x == 0:
# 		print(", angle is" + str(math.atan(y/x)))
# 	else:
# 		print(", angle is 0")


def initialize():
	global fireSignal
	global pin
	global ultrasonicInfo

#	fireSignal = activeFireSensor()
	if not fireSignal == NO_FIRE:
		currAction = 6
	#find an entrance
	ultrasonicInfo = distanceSensors.getDistances()
	pin = max(ultrasonicInfo)
	wheels.rotateAngle(pin * 45) #turn to face that pin

	#straighten, offloaded to the update function

def update(startTime):
	global fireSignal
	global currAction
	global checkActive
	global ultrasonicInfo

	ultrasonicInfo = distanceSensors.getDistances()
	fireSignal = passiveFireSensor()
	if not fireSignal == NO_FIRE and checkActive:
	#	fireSignal = activeFireSensor()
		#if not fireSignal == NO_FIRE:
		currAction = 6
	#	checkActive = False
	if not currAction == 0:
		movePattern()
		if not currAction == 5:
			return
	else:
		#if checkRoom:
		#	fireSignal = activeFireSensor()
		checkTurn()
		if currAction == 0:
			checkCollision()
			if currAction == 0:
				straighten()

def checkRoom():
	return math.fabs(ultrasonicInfo[0] - ultrasonicInfo[4]) < ULTRASONIC_THRESHOLD and math.fabs(ultrasonicInfo[2] == ultrasonicInfo[6])

def checkTurn():
	global currAction

	left = ultrasonicInfo[6] > TURN_THRESHOLD
	right = ultrasonicInfo[2] > TURN_THRESHOLD
	front = ultrasonicInfo[0] > TURN_THRESHOLD

	if right:
		currAction = 1
	#elif front:
	elif left:
		currAction = 2

def checkCollision():
	global currAction
	global actionStart

	for i in range(0, 8):
		if ultrasonicInfo[i] < FIRST_THRESHOLD:
			if ultrasonicInfo[i] < SECOND_THRESHOLD:
				if i < 4:
					wheels.rotateAngle(-90)
				else:
					wheels.rotateAngle(90)
				break
			if i == 0: #front@TODOFAWKJFHAKWJFHAW WAHHATTTTTTT
				#stop, wait a minute
				currAction = 4 #turn 180 degrees and go back
				actionStart = time.time()
				break;
			else:
				if ultrasonicInfo[1] >= FIRST_THRESHOLD: #if there is space to go NorthEast
					drive(math.sqrt(math.cos(ultrasonicInfo[2])**2 + math.sin(ultrasonicInfo[0]**2)))
				else:
					currAction = 4
					actionStart = time.time()
			break

def straighten():
	global currAction
	global actionStart

	if ultrasonicInfo[2] > SIDE_THRESHOLD:
		currAction = 5 #45 degree in direction of larger gap, go for one cycle, then turn 45 degrees back and continue
		actionStart = time.time()

def movePattern():
	global currAction
	global switch
	global actionStart
	global fireSignal

	#right turn
	if currAction == 1:
		#if (time.time() - actionStart) * TURN_TIME_CONST < TURN_TIME and switch == 0:
			#continue

		wheels.moveWheels(50,50)
		#print(str(time.time() - actionStart))
		#print("switch: " + str(switch))
		if (time.time() - actionStart) >= TURN_TIME and switch == 0:
			#print("SHOULDBETURNING")
			switch = 1
			wheels.rotate(75)
			time.sleep(0.04/9*75)
			wheels.rotate(0)
			time.sleep(1)
			actionStart = time.time()

		elif (time.time() - actionStart) >= TURN_TIME and switch == 1:
			#print("HERE:")
			currAction = 0 #finish
			switch = 0 #reset
		#@TODO: TURN_TIME should be amount of time it takes for the robot to get completely into the turn, and after
			#rotating get completely into the desired corridor
	#left turn
	elif currAction == 2:
		#if (time.time() - actionStart) * TURN_TIME_CONST < TURN_TIME and switch == 0:
			#continue
		if (time.time() - actionStart) >= TURN_TIME and switch == 0:
			switch = 1
			wheels.rotateAngle(-90)
			actionStart = time.time()
			movewheels(50,50)
		if (time.time() - actionStart) >= TURN_TIME and switch == 1:
			currAction = 0 #finish
			switch = 0 #reset
		#@TODO: TURN_TIME should be amount of time it takes for the robot to get completely into the turn, and after
			#rotating get completely into the desired corridor
	#turn 90 degrees from i
	elif currAction == 3:
		if pin > 4:	#if left side too close
			wheels.rotateAngle(90)
		else:		#if right side too close
			wheels.rotateAngle(-90)
		currAction = 0 #@TODO: for a couple of these, maybe call straighten once after just to keep on track?
	#turn 180 degrees and start going back
	elif currAction == 4:
		wheels.rotateAngle(180)
		currAction = 0
	#straighten
	elif currAction == 5:
		if ultrasonicInfo[2] > SIDE_THRESHOLD:
			drive(5, 15) #@TODO: this is rectangular coordinates for desired vector, w/ uncallibrated values
			
		elif ultrasonicInfo[2] < FIRST_THRESHOLD:
			drive(-5, 15)

		elif ultrasonicInfo[6] < FIRST_THRESHOLD:
			drive(5, 15)

		else:
			currAction = 0

	#following a fire, fireSignal gives pin direction
	elif currAction == 6:
		if not fireSignal == 0:	#near end will be doing smaller micro adjustments more often prob
			if fireSignal < 4: #if signal on the right side
				wheels.rotateAngle(fireSignal*45)
			else: #rotate ccw if on left side
				wheels.rotateAngle((8 - fireSignal)*45)

		list = [1,2,6,7]
		for i in list: #@TODO: does this include 7 or no?
			if ultrasonicInfo[i] < FIRST_THRESHOLD: #avoiding obstacles
				drive(-1 * math.cos(i*45) * 5, 15)
		
		fireSignal = passiveFireSensor()
		if fireSignal == NO_FIRE:
			#ireSignal = activeFireSensor()
			#if fireSignal == NO_FIRE:
			currAction = 0
		if currAction == 6:
			checkGo()

#-100, 100 gives angular speed ccw or cw
#def rotate(angularSpeed):
#def movewheels(leftwheel, rightwheel) #speed/power for left/right wheel, also -100, 100
def checkGo():
	if fireSignal == 0: #if 0 is front
		if ultrasonicInfo[0] < FIRST_THRESHOLD:
			let_it_go() #spray the candle

def let_it_go():
	print("LET IT GOOOOO")

ultrasonicInfo = [0,0,0,0,0,0,0,0] #length 8
fireInfo = [0,0,0,0,0,0,0,0,0,0] #length 10
fireSignal = NO_FIRE
checkActive = True

pin = 0 #pin used in both initialization and the one to turn away from if currAction == 3
switch = 0 #denotes stage of currAction

currAction = 0 #numeric values correspond to
		#particular movement patterns eg. left turn

actionStart = 0 #actionStart time

done = False


#start executing code here I guess?

#initialize()
#startTime = time.time()
#while (not done):
#	if (time.time() - startTime) * 1000 % 50 == 0: #every 50 milliseconds?
#		drive(0,10)
#		update(time.time())




# def main():
# 	print("START")
# 	actionStart = time.time()

# 	currAction = 1 #interchange with 1, 2 to test right/left turns
# 	while (not done):
# 		#print("HEYYY")
		
# 		movePattern()
# 		wheels.moveWheels(50,50)

# 		time.sleep(0.0004)

# if __name__ == "__main__":
# 	main()


# actionStart = time.time()
# currAction = 1
# while (not done):
# 	movePattern()
# 	wheels.moveWheels(50,50)

# 	time.sleep(0.050)



wheels.moveWheels(50,50)
time.sleep(3)
# #print(str(time.time() - actionStart))
# #print("switch: " + str(switch))
# time.sleep(TURN_TIME)
# wheels.moveWheels(0,0)
# wheels.rotate(75)
# time.sleep(0.04/9*75)
# wheels.rotate(0)
# time.sleep(1)
# wheels.moveWheels(50,50)
# time.sleep(1)