import move
import time
import math

TIME_TURN_1DEGREE = 0.04/9

motor1 = move.servoMove(14)
motor2 = move.servoMove(15)

def moveWheels(left, right):
	motor1.move(-left)
	motor2.move(right)

def rotate(speed):
	moveWheels(speed,-speed)

def rotateAngle(angle):
	moveWheels(0,0)
	time.sleep(1)
	startTime = time.time()
	stopTime = startTime + TIME_TURN_1DEGREE * math.fabs(angle)
	while time.time() < stopTime:
		speed = 75 * angle / math.fabs(angle) #* (stopTime - time.time()) * 2
		print("ERE")
		rotate(speed)

	# rotate(-speed)
	# time.sleep(0.01)
	moveWheels(0,0)
	time.sleep(1)

def drive(speed):
	moveWheels(speed, speed)